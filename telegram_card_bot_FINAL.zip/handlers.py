# ✅ handlers.py (Full Code)
from aiogram import Dispatcher, types
import sqlite3
from io import BytesIO
from config import ADMIN_CHANNEL_ID
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.dispatcher.filters import Text

ADMIN_IDS = [7670747174]
temp_upload = {}

async def start(msg: types.Message):
    user_id = msg.from_user.id
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    cursor.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    conn.commit()
    await msg.answer(f"Welcome {msg.from_user.first_name}

🪪 Profile →
💰 Deposit →
📋 Listings →
🛒 Buy")

async def profile(msg: types.Message):
    user_id = msg.from_user.id
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    cursor.execute("SELECT balance, deposit_history FROM users WHERE user_id = ?", (user_id,))
    data = cursor.fetchone()
    if data:
        balance, history = data
        await msg.answer(f"👤 User ID: {user_id}
💰 Balance: {balance} LTC
📝 Deposit History:
{history}")
    else:
        await msg.answer("Profile not found.")

async def show_cards(msg: types.Message):
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    cursor.execute("SELECT type, number FROM cards WHERE status='available' LIMIT 5")
    cards = cursor.fetchall()
    if not cards:
        await msg.answer("No cards available.")
        return
    response = ""
    for card in cards:
        response += f"{card[0]}: {card[1]}
"
    await msg.answer(response + "
Send 'Next' to see more.")

async def show_more(msg: types.Message):
    await msg.answer("Next 5 cards will be shown here (pagination not implemented yet).")

async def deposit(msg: types.Message):
    user_id = msg.from_user.id
    amount = 0.05
    YOUR_LTC_ADDRESS = "LW3fYW94VUHuT9KXk3uMsGESW2eYHCZbjx"

    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET balance = balance + ?, deposit_history = deposit_history || ? WHERE user_id = ?",
                   (amount, f"{amount} LTC received
", user_id))
    conn.commit()

    caption = f"💸 Send *exactly* `{amount} LTC` to this address:

`{YOUR_LTC_ADDRESS}`

✅ After payment, your balance has been updated."

    await msg.answer(caption, parse_mode="Markdown")

async def buy(msg: types.Message):
    user_id = msg.from_user.id
    full_name = msg.from_user.full_name
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, type, number FROM cards WHERE status='available' LIMIT 1")
    card = cursor.fetchone()
    if not card:
        return await msg.answer("No cards left.")
    card_id, card_type, card_num = card
    cursor.execute("UPDATE cards SET status='sold' WHERE id=?", (card_id,))
    cursor.execute("UPDATE users SET balance = balance - 1, deposit_history = deposit_history || ? WHERE user_id = ?",
                   (f"Bought: {card_type} {card_num}
", user_id))
    conn.commit()
    await msg.answer(f"✅ You bought a card:
{card_type}: {card_num}")

    kb = InlineKeyboardMarkup().add(
        InlineKeyboardButton("✅ Confirmed Delivered", callback_data=f"confirm_{user_id}_{card_id}")
    )
    await msg.bot.send_message(
        chat_id=ADMIN_CHANNEL_ID,
        text=f"🛒 *New Order Received!*
👤 User: [{full_name}](tg://user?id={user_id})
🆔 ID: `{user_id}`
💳 Card: `{card_type}: {card_num}`",
        parse_mode="Markdown",
        reply_markup=kb
    )

async def handle_confirm_callback(call: types.CallbackQuery):
    if call.from_user.id not in ADMIN_IDS:
        return await call.answer("❌ Not allowed")
    await call.message.edit_reply_markup()
    await call.message.reply("✅ Order marked as delivered.")

async def admin_panel(msg: types.Message):
    if msg.from_user.id not in ADMIN_IDS:
        return await msg.answer("❌ You are not admin.")
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("➕ Add Card", callback_data="add_card"),
        InlineKeyboardButton("🚫 Ban User", callback_data="ban_user"),
        InlineKeyboardButton("✅ Unban User", callback_data="unban_user"),
        InlineKeyboardButton("💸 Add Balance", callback_data="add_balance")
    )
    await msg.answer("🔐 Admin Panel:", reply_markup=kb)

async def handle_admin_callbacks(call: types.CallbackQuery):
    if call.from_user.id not in ADMIN_IDS:
        return await call.answer("Unauthorized")

    if call.data == "add_card":
        kb = InlineKeyboardMarkup(row_width=3)
        kb.add(
            InlineKeyboardButton("💳 Visa", callback_data="cardtype_Visa"),
            InlineKeyboardButton("🎟️ Master", callback_data="cardtype_Master"),
            InlineKeyboardButton("💡 Amex", callback_data="cardtype_Amex")
        )
        await call.message.answer("Select card type:", reply_markup=kb)

    elif call.data.startswith("cardtype_"):
        card_type = call.data.split("_")[1]
        temp_upload[call.from_user.id] = card_type
        await call.message.answer(f"✏️ Send list of {card_type} cards, one per line:")

async def card_upload_handler(msg: types.Message):
    user_id = msg.from_user.id
    if user_id not in temp_upload:
        return
    card_type = temp_upload.pop(user_id)
    cards = msg.text.strip().split("
")
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    for c in cards:
        if c.strip():
            cursor.execute("INSERT INTO cards (type, number) VALUES (?, ?)", (card_type, c.strip()))
    conn.commit()
    await msg.answer(f"✅ Added {len(cards)} {card_type} cards.")

async def total_users(msg: types.Message):
    if msg.from_user.id not in ADMIN_IDS:
        return await msg.answer("❌ You are not admin.")
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM users")
    count = cursor.fetchone()[0]
    await msg.answer(f"👥 Total Users: {count}")

def register_handlers(dp: Dispatcher):
    dp.register_message_handler(start, commands=["start"])
    dp.register_message_handler(profile, lambda msg: msg.text == "🪪 Profile →")
    dp.register_message_handler(deposit, lambda msg: msg.text == "💰 Deposit →")
    dp.register_message_handler(show_cards, lambda msg: msg.text == "📋 Listings →")
    dp.register_message_handler(show_more, lambda msg: msg.text.lower() == "next")
    dp.register_message_handler(buy, lambda msg: msg.text == "🛒 Buy")
    dp.register_message_handler(admin_panel, commands=["admin"])
    dp.register_message_handler(total_users, commands=["users"])
    dp.register_callback_query_handler(handle_admin_callbacks, Text(startswith="add_card") | Text(startswith="cardtype_"))
    dp.register_callback_query_handler(handle_confirm_callback, Text(startswith="confirm_"))
    dp.register_message_handler(card_upload_handler)
