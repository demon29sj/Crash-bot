import sqlite3

def initialize_db():
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance REAL DEFAULT 0,
            deposit_history TEXT DEFAULT ''
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS cards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT,
            number TEXT,
            status TEXT DEFAULT 'available'
        )
    """)
    conn.commit()
    conn.close()
