from aiogram import Bot, Dispatcher, executor
from config import BOT_TOKEN
from handlers import register_handlers
from db import initialize_db

bot = Bot(token=7673701781:AAGZyP8VaJmm-10ui1zDWe7m-LkUpFcfNTg)
dp = Dispatcher(bot)

initialize_db()
register_handlers(dp)

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
